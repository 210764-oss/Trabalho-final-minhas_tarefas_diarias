import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static Future<List<dynamic>> buscarFeriados(int ano) async {
    try {
      final resposta = await http.get(
        Uri.parse('https://brasilapi.com.br/api/feriados/v1/$ano'),
      );
      if (resposta.statusCode == 200) {
        return json.decode(resposta.body);
      }
      return [];
    } catch (e) {
      return [];
    }
  }
}