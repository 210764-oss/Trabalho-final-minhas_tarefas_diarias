import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/tarefa.dart';

class StorageService {
  static const _chave = 'tarefas';

  static Future<List<Tarefa>> carregarTarefas() async {
    final prefs = await SharedPreferences.getInstance();
    final String? dados = prefs.getString(_chave);
    if (dados == null) return [];
    List lista = json.decode(dados);
    return lista.map((item) => Tarefa.fromMap(item)).toList();
  }

  static Future<void> salvarTarefas(List<Tarefa> tarefas) async {
    final prefs = await SharedPreferences.getInstance();
    List<Map> lista = tarefas.map((t) => t.toMap()).toList();
    await prefs.setString(_chave, json.encode(lista));
  }
}