import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/tarefa.dart';
import '../widgets/botao_padrao.dart';

class TelaCadastro extends StatefulWidget {
  const TelaCadastro({super.key});

  @override
  State<TelaCadastro> createState() => _TelaCadastroState();
}

class _TelaCadastroState extends State<TelaCadastro> {
  final _formKey = GlobalKey<FormState>();
  final _ctrlTitulo = TextEditingController();
  final _ctrlDescricao = TextEditingController();
  final _ctrlData = TextEditingController();
  String _prioridade = 'Média';

  Future<void> _salvar() async {
    if (!_formKey.currentState!.validate()) return;
    final prefs = await SharedPreferences.getInstance();
    List<dynamic> lista = [];
    final String? dadosAntigos = prefs.getString('tarefas');
    if (dadosAntigos != null) lista = json.decode(dadosAntigos);

    Tarefa nova = Tarefa(
      id: DateTime.now().toString(),
      titulo: _ctrlTitulo.text,
      descricao: _ctrlDescricao.text,
      data: _ctrlData.text,
      prioridade: _prioridade,
    );

    lista.add(nova.toMap());
    await prefs.setString('tarefas', json.encode(lista));

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ Tarefa salva com sucesso!')),
      );
      _formKey.currentState!.reset();
      _ctrlData.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Cadastrar Nova Tarefa', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            TextFormField(controller: _ctrlTitulo, decoration: const InputDecoration(labelText: 'Título', border: OutlineInputBorder()),
              validator: (v) => v?.isEmpty ?? true ? 'Informe o título' : null),
            const SizedBox(height: 15),
            TextFormField(controller: _ctrlDescricao, decoration: const InputDecoration(labelText: 'Descrição', border: OutlineInputBorder()), maxLines: 2),
            const SizedBox(height: 15),
            TextFormField(controller: _ctrlData, decoration: const InputDecoration(labelText: 'Data (ex: 20/10/2026)', border: OutlineInputBorder()),
              validator: (v) => v?.isEmpty ?? true ? 'Informe a data' : null),
            const SizedBox(height: 15),
            DropdownButtonFormField(value: _prioridade, decoration: const InputDecoration(labelText: 'Prioridade', border: OutlineInputBorder()),
              items: const ['Baixa', 'Média', 'Alta'].map((p) => DropdownMenuItem(value: p, child: Text(p))).toList(),
              onChanged: (v) => setState(() => _prioridade = v ?? 'Média')),
            const SizedBox(height: 25),
            BotaoPadrao(texto: 'Salvar Tarefa', aoPressionar: _salvar),
          ],
        ),
      ),
    );
  }
}