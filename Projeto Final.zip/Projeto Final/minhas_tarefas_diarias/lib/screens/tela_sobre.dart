import 'package:flutter/material.dart';

class TelaSobre extends StatelessWidget {
  const TelaSobre({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(25),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Text('Minhas Tarefas Diárias', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 15),
        const Text('Aplicativo feito como trabalho final da disciplina de Desenvolvimento Mobile.\n\nAjuda a organizar compromissos, salvar tarefas e consultar feriados.', textAlign: TextAlign.center),
        const SizedBox(height: 30),
        ElevatedButton(onPressed: () {
          showDialog(context: context, builder: (ctx) => AlertDialog(title: const Text('Sobre o App'),
            content: const Text('Versão 1.0\nDesenvolvido em Flutter\nPersistência: SharedPreferences\nAPI: BrasilAPI'),
            actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Fechar'))]));
        }, child: const Text('Mais Informações')),
      ]))));
  }
}