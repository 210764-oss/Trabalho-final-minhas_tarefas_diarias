 import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../models/tarefa.dart';
import '../services/storage_service.dart';

class TelaLista extends StatefulWidget {
  final List<Tarefa> tarefas;
  final Function aoAtualizar;

  const TelaLista({
    super.key,
    required this.tarefas,
    required this.aoAtualizar,
  });

  @override
  State<TelaLista> createState() => _TelaListaState();
}

class _TelaListaState extends State<TelaLista> {
  late List<Tarefa> _lista;

  @override
  void initState() {
    super.initState();
    _lista = widget.tarefas;
  }

  @override
  void didUpdateWidget(covariant TelaLista oldWidget) {
    super.didUpdateWidget(oldWidget);
    _lista = widget.tarefas;
  }

  Future<void> _alternarConcluida(int indice) async {
    setState(() {
      _lista[indice].concluida = !_lista[indice].concluida;
    });
    await StorageService.salvarTarefas(_lista);
    widget.aoAtualizar();
  }

  Future<void> _excluir(int indice) async {
    final confirmar = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Confirmar Exclusão'),
        content: const Text('Tem certeza que deseja excluir essa tarefa?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (confirmar == true) {
      setState(() {
        _lista.removeAt(indice);
      });
      await StorageService.salvarTarefas(_lista);
      widget.aoAtualizar();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tarefa excluída!')),
        );
      }
    }
  }

  void _compartilhar() {
    String texto = 'Minhas Tarefas:\n\n';
    for (var t in _lista) {
      texto += '${t.concluida ? '[Concluída]' : '[Pendente]'} ${t.titulo} — ${t.data}\n';
      if (t.descricao.isNotEmpty) {
        texto += '   ${t.descricao}\n';
      }
    }
    Share.share(texto);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(15),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${_lista.length} Tarefas',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              ElevatedButton.icon(
                onPressed: _lista.isNotEmpty ? _compartilhar : null,
                icon: const Icon(Icons.share),
                label: const Text('Compartilhar'),
              ),
            ],
          ),
        ),
        Expanded(
          child: _lista.isEmpty
              ? const Center(
                  child: Text(
                    'Nenhuma tarefa cadastrada ainda!',
                    style: TextStyle(fontSize: 16),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  itemCount: _lista.length,
                  itemBuilder: (ctx, i) {
                    final tarefa = _lista[i];
                    return Card(
                      elevation: 4,
                      margin: const EdgeInsets.only(bottom: 12),
                      child: ListTile(
                        leading: Checkbox(
                          value: tarefa.concluida,
                          onChanged: (_) => _alternarConcluida(i),
                        ),
                        title: Text(
                          tarefa.titulo,
                          style: TextStyle(
                            decoration: tarefa.concluida
                                ? TextDecoration.lineThrough
                                : null,
                          ),
                        ),
                        subtitle: Text('${tarefa.descricao} • ${tarefa.data}'),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _excluir(i),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}