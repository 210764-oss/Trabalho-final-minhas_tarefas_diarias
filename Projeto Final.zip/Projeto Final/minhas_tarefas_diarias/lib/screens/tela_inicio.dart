 import 'package:flutter/material.dart';
import '../models/tarefa.dart';
import '../services/storage_service.dart';
import 'tela_cadastro.dart';
import 'tela_lista.dart';
import 'tela_feriados.dart';
import 'tela_sobre.dart';

class TelaInicio extends StatefulWidget {
  const TelaInicio({super.key});

  @override
  State<TelaInicio> createState() => _TelaInicioState();
}

class _TelaInicioState extends State<TelaInicio> {
  List<Tarefa> tarefas = [];
  int telaAtual = 0;

  @override
  void initState() {
    super.initState();
    _carregar();
  }

  Future<void> _carregar() async {
    final lista = await StorageService.carregarTarefas();
    setState(() {
      tarefas = lista;
    });
  }

  void _alternarTela(int indice) {
    setState(() {
      telaAtual = indice;
    });
  }

  @override
  Widget build(BuildContext context) {
    List<Widget> telas = [
      TelaLista(
        tarefas: tarefas,
        aoAtualizar: _carregar,
      ),
      const TelaCadastro(),
      const TelaFeriados(),
      const TelaSobre(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Minhas Tarefas Diárias'),
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.blueAccent),
              child: Text('Menu', style: TextStyle(color: Colors.white, fontSize: 22)),
            ),
            ListTile(
              leading: const Icon(Icons.list),
              title: const Text('Minhas Tarefas'),
              onTap: () {
                setState(() => telaAtual = 0);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.add),
              title: const Text('Cadastrar'),
              onTap: () {
                setState(() => telaAtual = 1);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.calendar_today),
              title: const Text('Feriados'),
              onTap: () {
                setState(() => telaAtual = 2);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.info),
              title: const Text('Sobre'),
              onTap: () {
                setState(() => telaAtual = 3);
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
      body: telas[telaAtual],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: telaAtual,
        onTap: _alternarTela,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.blueAccent,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Lista'),
          BottomNavigationBarItem(icon: Icon(Icons.add), label: 'Nova'),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_today), label: 'Feriados'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'Sobre'),
        ],
      ),
    );
  }
}