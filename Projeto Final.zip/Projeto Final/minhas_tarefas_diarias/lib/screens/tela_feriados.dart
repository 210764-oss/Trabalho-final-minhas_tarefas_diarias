import 'package:flutter/material.dart';
import '../services/api_service.dart';

class TelaFeriados extends StatefulWidget {
  const TelaFeriados({super.key});

  @override
  State<TelaFeriados> createState() => _TelaFeriadosState();
}

class _TelaFeriadosState extends State<TelaFeriados> {
  List<dynamic> feriados = [];
  bool carregando = true;

  @override
  void initState() {
    super.initState();
    _buscar();
  }

  Future<void> _buscar() async {
    final dados = await ApiService.buscarFeriados(2026);
    setState(() { feriados = dados; carregando = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: carregando
      ? const Center(child: CircularProgressIndicator())
      : feriados.isEmpty
        ? const Center(child: Text('Nenhum feriado encontrado.'))
        : ListView.builder(padding: const EdgeInsets.all(15), itemCount: feriados.length,
            itemBuilder: (ctx, i) {
              final f = feriados[i];
              return Card(margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(title: Text(f['name']), subtitle: Text(f['date'])));
            }));
  }
}