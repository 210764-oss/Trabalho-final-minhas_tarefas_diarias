 import 'package:flutter/material.dart';
import 'screens/tela_inicio.dart';

void main() {
  runApp(const MeuApp());
}

class MeuApp extends StatelessWidget {
  const MeuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Minhas Tarefas Diárias',
      theme: ThemeData(primarySwatch: Colors.blue, useMaterial3: true),
      home: const TelaInicio(),
      debugShowCheckedModeBanner: false,
    );
  }
}