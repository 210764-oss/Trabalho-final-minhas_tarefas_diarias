class Tarefa {
  final String id;
  final String titulo;
  final String descricao;
  final String data;
  final String prioridade;
  bool concluida;

  Tarefa({
    required this.id,
    required this.titulo,
    required this.descricao,
    required this.data,
    required this.prioridade,
    this.concluida = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'titulo': titulo,
      'descricao': descricao,
      'data': data,
      'prioridade': prioridade,
      'concluida': concluida,
    };
  }

  static Tarefa fromMap(Map<String, dynamic> map) {
    return Tarefa(
      id: map['id'],
      titulo: map['titulo'],
      descricao: map['descricao'],
      data: map['data'],
      prioridade: map['prioridade'],
      concluida: map['concluida'] ?? false,
    );
  }
}