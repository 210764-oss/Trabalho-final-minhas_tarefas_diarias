 import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:minhas_tarefas_diarias/main.dart';

void main() {
  testWidgets('App carrega corretamente', (WidgetTester tester) async {
    await tester.pumpWidget(const MeuApp());

    expect(find.text('Minhas Tarefas Diárias'), findsOneWidget);
  });
}